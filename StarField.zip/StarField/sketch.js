
var arrStar = [];
var StarCount = 500;

function setup() {
	createCanvas(window.innerWidth, window.innerHeight);
	background(0);

	for(let i = 0; i < StarCount; i++){
		var star = new Star();
		arrStar[i] = star;
	}

}

function draw() {
	translate(width/2, height/2);
	background(0);
  for(let i = 0; i < StarCount; i ++){
  	arrStar[i].update();
  	arrStar[i].show();

  }
}


function Star(){
	var x = Random(-width, width);
	var y = Random(-height, height);
	var z = Random();
	var pz = z;


	x = Random(0, width);
	y = Random(0, height);


	this.show = function(){
		fill(255);
		noStroke();


		var sx = map(x / z, 0, 1, 0, width);
		var sy = map(y / z, 0, 1, 0, height)

		var r = map(z, 0, width, 16, 0);
		ellipse(sx, sy, r, r);
		console.log("Drawing star at" + sx + " " + sy)

		var px = map(x / pz, 0, 1, 0, width);
		var py = map(y / pz, 0, 1, 0, height);

		pz = z;

		 stroke(255);
  		 line(px, py, sx, sy);
 
	}

	this.update = function(){
		z = z - 10;
		if(z < 1){
			z = width;
			var x = Random(-width, width);
			var y = Random(-height, height);
			pz = z;
		}
	}

	function Random(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

}




